import React from 'react'
import Hero from '../shared/Hero'

const Home = () => {
  return (
    <div className='bg-hero-pattern bg-cover bg-no-repeat  min-h-screen'>
        <Hero/>
      
    </div>
  )
}

export default Home
